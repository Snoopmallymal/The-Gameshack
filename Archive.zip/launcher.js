// Opens The News Page
function openNews() {
    window.open(path, "_blank", "", "false")
}

//Launches a Game
function launchGame(path) {
    window.open(path, "_self", "", "false"	)
}